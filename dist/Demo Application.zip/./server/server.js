exports = {
  // args is a JSON block containing the payload information.
  // args['iparam'] will contain the installation parameter values.
  onTicketCreateHandler: function () {
    console.log("Ticket Creation is Working Fine");
  },
};

// exports = {
//   onTicketUpdateCallback: function (payload) {
//     console.log(
//       "Logging arguments from onTicketUpdate event: " + JSON.stringify(payload)
//     );
//   },
// };
